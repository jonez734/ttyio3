import os
import sys
import tty, termios, fcntl
import time
import types
import select
import errno
import socket

_RCSID = "$Id: ttyio.py,v 1.2 2003/09/25 14:20:55 jam Exp $"

DEBUG = False

# <http://www.python.org/doc/faq/library.html#how-do-i-get-a-single-keypress-at-a-time>
# http://craftsman-hambs.blogspot.com/2009/11/getch-in-python-read-character-without.html
def getch():
  fd = sys.stdin.fileno()

  oldterm = termios.tcgetattr(fd)

  newattr = termios.tcgetattr(fd)
  newattr[3] = newattr[3] & ~termios.ICANON & ~termios.ECHO
  termios.tcsetattr(fd, termios.TCSANOW, newattr)

  oldflags = fcntl.fcntl(fd, fcntl.F_GETFL)
  fcntl.fcntl(fd, fcntl.F_SETFL, oldflags | os.O_NONBLOCK)
  try:
      while 1:
              try:
                r, w, x = select.select([fd],[],[],0.250)
              except socket.error as e:
                echo("%r: %r" % (e.code, e.msg), level="error")
                if code == 4:
                  echo("interupted system call (tab switch?)")
                  continue
                #if code <> errno.EINTR:
                #  raise
                
              if len(r) == 1:
                ch = sys.stdin.read(1)
                return ch
  finally:
      termios.tcsetattr(fd, termios.TCSAFLUSH, oldterm)
      fcntl.fcntl(fd, fcntl.F_SETFL, oldflags)

  return ch

# <http://www.python.org/doc/faq/library.html#how-do-i-get-a-single-keypress-at-a-time>
# http://craftsman-hambs.blogspot.com/2009/11/getch-in-python-read-character-without.html
def getchbusywait():
  pass

# https://gist.github.com/sirpengi/5045885 2013-feb-27 in oftcphp sirpengi
# @since 20140529
def collapse(lst):
    def chunk(lst):
        ret = [lst[0],]
        for i in lst[1:]:
            if ord(i) == ord(ret[-1]) + 1:
                pass
            else:
                yield ret
                ret = []
            ret.append(i)
        yield ret
    chunked = chunk(lst)
    ranges = ((min(l), max(l)) for l in chunked)
    return ", ".join("{0}-{1}".format(*l) if l[0] != l[1] else l[0] for l in ranges)

def accept(prompt, options, default="", debug=False):
  if debug is True:
    echo("ttyio3.accept.100: options=%s" % (options), level="debug")
        
  default = default.upper() if default is not None else ""
  options = options.upper()
  foo = list(set(options))
  foo = sorted(foo)
  foo = collapse(list(foo))
      
  prompt += " [%s]" % (foo)
      
  sys.stdout.write("%s: " % (prompt))
  sys.stdout.flush()

  while 1:
    ch = getch().upper()
    
    if ch == "\n":
      return default
      if default is not None:
        return default
      else:
        return ch
    elif ch in options:
      return ch

def inputboolean(prompt, default=None):
	ch = accept(prompt, "YNTF", default)
	if ch == "Y":
		echo("Yes")
		return True
	elif ch == "T":
		echo("True")
		return True
	elif ch == "N":
		echo("No")
		return False
	elif ch == "F":
		echo("False")
		return False

def acceptboolean(prompt, default=None):
  echo("acceptboolean has been renamed to inputboolean", level="warn")
  return inputboolean(prompt, default)

# copied from bbsengine.py
def echo(buf="", stripcolor=False, level=None, datestamp=False, end="\n", **kw):
  import colorclass
  from dateutil.tz import tzlocal
  from datetime import datetime
  from time import strftime

  if datestamp is True:
    now = datetime.now(tzlocal())
    stamp = strftime("%Y-%b-%d %I:%M:%S%P %Z (%a)", now.timetuple())
    buf = "%s %s" % (stamp, buf)

  if level is not None:
    if level == "debug":
      buf = "{autoblue}** debug ** %s{/autoblue}" % (buf)
    elif level == "warn":
      buf = "{autoyellow}** warn ** %s{/autoyellow}" % (buf)
    elif level == "error":
      buf = "{autored}** error ** %s{/autored}" % (buf)
    elif level == "success":
      buf = "{autogreen}** success ** %s{/autogreen}" % (buf)

  if isinstance(buf, colorclass.Color) is False:
    buf = colorclass.Color(buf)

  if stripcolor is False:
    print(buf, end=end)
  else:
    print(buf.value_no_colors, end=end)
  return

# http://www.brandonrubin.me/2014/03/18/python-snippet-get-terminal-width/
def getterminalwidth():
  import subprocess
 
  command = ['tput', 'cols']
 
#  if sys.stdout.isatty() is False:
#    return False

  try:
    width = int(subprocess.check_output(command))
  except OSError as e:
    print("Invalid Command '{0}': exit status ({1})".format(command[0], e.errno))
    return False
  except subprocess.CalledProcessError as e:
    print("Command '{0}' returned non-zero exit status: ({1})".format(command, e.returncode))
    return False
  else:
    return width

def xtname(name):
  if sys.stdout.isatty() is False:
    return False
  echo("\x1b]0;%s\x07" % (name))
  return

def handlemenu(opts, title, items, oldrecord, currecord, prompt="option", defaulthotkey=""):
    hotkeys = {}

    hotkeystr = ""

    for item in items:
        label = item["label"].lower()
        hotkey = item["hotkey"].lower() if item.has_key("hotkey") else None
#        ttyio.echo("hotkey=%s" % (hotkey), level="debug")
        if hotkey is not None and hotkey in label:
            label = label.replace(hotkey.lower(), "[{autocyan}%s{/autocyan}]" % (hotkey.upper()), 1)
        else:
            label = "[{autocyan}%s{/autocyan}] %s" % (hotkey, label)
        if item.has_key("key"):
            key = item["key"]
            if oldrecord[key] != currecord[key]:
                buf = "%s: %s (was %s)" % (label, currecord[key], oldrecord[key])
            else:
                buf = "%s: %s" % (label, currecord[key])
        else:
            buf = label
        
        hotkeys[hotkey] = item # ["longlabel"] if item.has_key("longlabel") else None
        if hotkey is not None:
            hotkeystr += hotkey
        echo(buf,datestamp=False)
    
    if currecord != oldrecord:
      echo("{autoyellow}** NEEDS SAVE **{/autoyellow}", datestamp=False)
    
    echo()
  
    ch = accept(prompt, hotkeystr, defaulthotkey)
    ch = ch.lower()
    longlabel = hotkeys[ch]["longlabel"] if hotkeys[ch].has_key("longlabel") else None
    if longlabel is not None:
        echo("{autocyan}%s{/autocyan} -- %s" % (ch.upper(), longlabel), datestamp=False)
    else:
        echo("{autocyan}%s{/autocyan}" % (ch.upper()), datestamp=False)
    return hotkeys[ch]

# bbsengine.input*() moved to ttyio
# @since 20170419
def inputdate(prompt, oldvalue=None, **kw):
  if oldvalue is not None:
    buf = inputstring(prompt, datestamp(oldvalue), **kw)
  else:
    buf = inputstring(prompt, **kw)
  epoch = getdate.getdate(buf)
  tz = LocalTimezone()
  stamp = datetime.fromtimestamp(epoch, tz)
  return stamp # datetime.fromtimestamp(epoch)

# @TODO: limit input to digits
def inputinteger(prompt, oldvalue=None):
  buf = inputstring(prompt, oldvalue)
  return int(buf)

# @since 20110323
# @since 20190913
def inputstring(prompt:str, value=None, **kw):
  import readline
  def preinputhook():
    readline.insert_text(str(foo))
    readline.redisplay()
#    ttyio.echo("inputstring.preinputhook.100: oldvalue=%s" % (foo), level="debug")

  if value is not None:
    readline.set_pre_input_hook(preinputhook)

  try:
    inputfunc = raw_input
  except NameError:
    inputfunc = input
  
  try:
    buf = inputfunc(prompt)
  except KeyboardInterrupt:
    echo("INTR")
    return None
  except EOFError:
    echo("EOF")
    return None

  if value is not None:
    readline.set_pre_input_hook(None)

  if buf is None or buf == "":
    if "noneok" in kw and kw["noneok"] is True:
      return None
    else:
      return value
  else:
    return buf

def inputboolean(prompt, options="YN", default=""):
  ch = accept(prompt, options, default)
  if ch == "Y":
    echo("Yes")
    return True
  elif ch == "T":
    echo("True")
    return True
  elif ch == "N":
    echo("No")
    return False
  elif ch == "F":
    echo("False")
    return False
  return None

#def input(func, prompt, oldvalue, opts=None, completerinstance=None):
#    buf = func(prompt, oldvalue)
#    if "noneok" in opts and opts.noneok is True and (buf is None or buf == ""):
#        return None
#
#    if buf is not None and buf != "":
#        return buf
#
#    return oldvalue

class inputcompleter(object):
  def __init__(self, dbh, opts, table, primarykey):
    self.matches = []
    self.dbh = dbh
    self.opts = opts
    self.table = table
    self.primarykey = primarykey
    echo("ttyio3.inputcompleter.table=%s, .primarykey=%s" % (table, primarykey), level="debug")

  def getmatches(self, text):
    echo("ttyio3.inputcompleter.100: text=%s" % (text), level="debug")
    
    sql = "select %s from %s" % (self.primarykey, self.table)
    if text == "":
        dat = ()
    else:
        sql += " where %s ilike %s" % (self.primarykey)
        dat = (text+"%",)
    cur = self.dbh.cursor()
    try:
      cur.execute(sql, dat)
    except Exception as e:
      echo("ttyio3.inputcompleter.200: e=%s" % (e), level="error")

    res = cur.fetchall()

    foo = []
    for rec in res:
      foo.append(rec[self.primarykey])

    cur.close()
    
    return foo

  def completer(self, text, state):
    # ttyio.echo("completer.100: state=%r text=%r" % (state, text), level="debug")
    
    if state == 0:
      if text:
        self.matches = self.getmatches(text)
      else:
        self.matches = []

    if state < len(self.matches):
      return self.matches[state]
    
    return None


def areyousure(prompt="are you sure?", default="N", options="YN"):
  res = inputboolean(prompt, default=default, options=options)
  if res is True:
    return 0
  return 1

if __name__ == "__main__":
#  print _RCSID
  print(accept("[A, B, C, D]", "ABCD", None))
